\i 'create_tables.sql';
\i 'insert_data.sql';
\i 'create_views.sql';
\i 'create_indexes.sql'