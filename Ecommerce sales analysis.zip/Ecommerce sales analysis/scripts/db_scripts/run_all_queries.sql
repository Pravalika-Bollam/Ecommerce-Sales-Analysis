\i 'order_status_queries.sql';
\i 'customer_analysis.sql';
\i 'category_sales.sql';
\i 'sales_distribution.sql';
\i 'sku_sales.sql';
\i 'size_sales.sql';
\i 'international_sales.sql';
\i 'comparison_queries.sql'
